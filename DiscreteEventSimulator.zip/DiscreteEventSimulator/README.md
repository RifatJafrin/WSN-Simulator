# README #

Hi, the code for DIscrete event simulator is stored here

### What is this repository for? ###

This is an implementation of Discrete event simulator to validate the ontology deployment protocol. 

### How do I get set up? ###

All necessary files are there for you to start using the code. You will need a working Eclipse IDE. 
The detail configuration and set-up environment can be found in the thesis paper.
You can change different parameter through the the exp.properties File.
The codes take the input through exp.properties file and generate report which can be found in the report folder. 


### Who do I talk to? ###

contact: jafrinrifat@gmail.com