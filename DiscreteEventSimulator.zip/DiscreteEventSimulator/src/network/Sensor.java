package network;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import protocol.AggregationTable;
import protocol.AggregationTable.AggregationTableEntry;
import protocol.ProtocolMessage;
import protocol.ReceivedMessage;
import simulation.Configuration;
import simulation.DiscreteEventSimulator;

public class Sensor {
List<CacheItem> cache;
int id;
List<Integer> neighbors;
List<Integer> capableNodes;


List<ReceivedMessage> messageQueue;
boolean isCapable;

int position_x;
int position_y;

AggregationTable aggregatedMessages;

final static Logger logger = Logger.getLogger(Sensor.class);


public Sensor(int id){
	messageQueue=new ArrayList<ReceivedMessage>(5);
	neighbors=new ArrayList<Integer>(1);
	this.id=id;
	this.position_x=0;
	this.position_y=0;
	isCapable=false;
	
	logger.info("Sensor "+ id+ " is initialized");
}

public void updateCache(int broadcasetId, int sourceAddress,  int receiptionTime){
	if(cache==null){
		cache=new ArrayList<CacheItem>(1);
		
	}
	CacheItem entry=new CacheItem(broadcasetId, sourceAddress, receiptionTime);
	cache.add(entry);
	logger.info("Cache is updated for sensor "+ id);
}

public void acceptMessage(int sourceAddress, ProtocolMessage message, int receiptionTime){
	messageQueue.add(new ReceivedMessage(message,receiptionTime));
	logger.info("Message is sent to sensor "+ id);
}


public int getDestination(int broadcast_id) {

	for(CacheItem entry:cache){
		if(entry.getBroadcastId()==broadcast_id){
			return entry.source_address;
		}
	}
	logger.error("Destination is not found");
	return -1;
}	

public boolean isDuplicateMessage(int broadcast_id){
	if(cache==null){
		return false;
	}
	for(CacheItem cacheItem:cache){
		if(cacheItem.getBroadcastId()==broadcast_id){
			logger.info("Duplicate message found");
			return true;
		}
	}
	return false;
}


public List<Integer> getCapableNodes() {
	return capableNodes;
}


public void AddToCapableNodes(int capableNodeID) {
	if(capableNodes==null){
		capableNodes= new ArrayList<Integer>(1);
	}
	this.capableNodes.add(capableNodeID);
}

public void AddToCapableNodes(List<Integer> capableNodes) {
	if(this.capableNodes==null){
		this.capableNodes= new ArrayList<Integer>(capableNodes.size());
	}
	for(Integer n:capableNodes){
		if(!this.capableNodes.contains(n)){
			this.capableNodes.add(n);
		}
	}
			logger.info("Capable node list is updated for sensor "+ id);
}


public List<Integer> getNeighbors() {
	return neighbors;
}




public int getPosition_x() {
	return position_x;
}

public void setPosition_x(int position_x) {
	this.position_x = position_x;
}

public int getPosition_y() {
	return position_y;
}

public void setPosition_y(int position_y) {
	this.position_y = position_y;
}




public List<CacheItem> getCache() {
	return cache;
}

public void setCache(List<CacheItem> cache) {
	this.cache = cache;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}



public List<ReceivedMessage> getMessageQueue() {
	return messageQueue;
}

public ReceivedMessage dequeue(){
	return messageQueue.size()>0?messageQueue.remove(0):null; 
	
}

public void setMessageQueue(List<ReceivedMessage> messageQueue) {
	this.messageQueue = messageQueue;
}

public boolean isCapable() {
	return isCapable;
}

public void setCapable() {
	this.isCapable = true;
}



public void addNeighbor(int i){
	neighbors.add(i);
}



@Override
public String toString() {
	return String.valueOf(id);
}

	


	public void setPosition(int x, int y) {
	position_x=x;
	position_y=y;
		
	}


	public int getElapsedTime(int broadcast_id){
		for(CacheItem entry:cache){
			if(entry.broadcast_id==broadcast_id){
				return DiscreteEventSimulator.currentTime-entry.receiptionTime;
			}
		}
		return -1000;
	}
	
	public class CacheItem{
		int broadcast_id;
		int source_address;
		int receiptionTime;
		
		public CacheItem(int broadcasetId, int sourceAddress,  int receiptionTime){
			this.broadcast_id=broadcasetId;
			this.source_address=sourceAddress;
			this.receiptionTime=receiptionTime;
		}
		int getBroadcastId(){
			return broadcast_id;
		}
		int getSourceAddress(){
			return source_address;
		}
		
		int getReceiptionTime(){
			return receiptionTime;
		}
	}

	public  List<AggregationTableEntry> processAgrregatedMessage() {
		return aggregatedMessages==null?null:aggregatedMessages.generateResponseMessageRecords();
		
	}
	
	public void updateAggregationTable(int broadcast_id, int originator, List<Integer> capableNodes){
		if(aggregatedMessages==null) aggregatedMessages=new AggregationTable();
		aggregatedMessages.updateAggregationTable(broadcast_id, originator, capableNodes);
	}
	public void updateAggregationTable(int broadcast_id, int originator,
			int capableNode) {
		List<Integer> capableNodes=new ArrayList<Integer>(1);
		capableNodes.add(capableNode);
		updateAggregationTable(broadcast_id, originator, capableNodes);
	}

	public boolean hasPendingMessage() {
		return aggregatedMessages==null?false:aggregatedMessages.doesHavePendingMessage();
	}
	

	
}
