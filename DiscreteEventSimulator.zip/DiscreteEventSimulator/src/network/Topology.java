package network;

import simulation.Configuration;

	public abstract class Topology {
	Network network;
	
	Configuration configuration;
	public static int TOPOLOGY_GRID=0;
	public static int TOPOLOGY_POISSION=0;
	
	public void build(){
		//build topology here
	}
	
	public void print(){
		for(int id=0; id<network.getNodes().size(); id++){
			Sensor node=network.getNodes().get(id);
			System.out.println("id"+ id + ", x:"+ node.getPosition_x()+ ", y:"+ node.getPosition_y()+", Neighbors:"+ node.getNeighbors()  );
		}
	}

	public boolean isNeighbor(int x1, int y1, int x2, int y2, double range){
		double D=Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
		return D<=range;
	}
	
	public void showTopology(){
		GraphPresentor f=new GraphPresentor(2, 400, 400);
	}
	
	
}
