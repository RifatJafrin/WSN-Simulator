package network;

public class TopologyFactory {

	public static String GRID="grid";
	public static String GAUSSIAN="gaussian";
	
	public static Topology getTopology(String topology) {
		if(topology.equals(GRID)){
			return GridTopology.getInstance();
		}else if(topology.equals(GAUSSIAN)){
			return GaussianTopology.getInstance();
		}else{
			return null;
		}
	}
}
