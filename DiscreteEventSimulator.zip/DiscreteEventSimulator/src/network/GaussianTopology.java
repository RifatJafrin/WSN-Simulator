package network;

import java.util.Random;

import simulation.Configuration;

public class GaussianTopology extends Topology{
	public static GaussianTopology uniformTopology;
	public double avgNeighbors;
	public double minNeighbors;
	public double maxNeighbors;

	public GaussianTopology() {
		network=Network.getInstance();
		configuration=Configuration.getInstance();
		
	}

	public static Topology getInstance(){
		if(uniformTopology==null){
			uniformTopology=new GaussianTopology();
		}
			return uniformTopology;
		
	}

		@Override
		public void build(){
			network.initializeNetwork();
			avgNeighbors=0.0;
			minNeighbors=network.nodes.size();
			maxNeighbors=-1.0;
			
			//set position of nodes
			Random r=new Random();
			double mean=Configuration.getInstance().getMean();
			double standardDeviation=Configuration.getInstance().getStandardDeviation();
			double connectivityFactor=Configuration.getInstance().getRange()/2;
			
			for(int id=0; id<network.getNodes().size(); id++){
				double x = r.nextGaussian() * standardDeviation + mean;
				double y = r.nextGaussian() * standardDeviation + mean;
				network.getNodes().get(id).setPosition((int) Math.round(x*connectivityFactor), (int) Math.round(y*connectivityFactor));
			}
			
			//set neighbors of nodes

			for(int id=0; id<network.getNodes().size(); id++){
				Sensor node1=network.getSensor(id);
				int count=0;
				for(int id2=0; id2<network.getNodes().size(); id2++){
					if(id!=id2){
						if(isNeighbor(node1.getPosition_x(), node1.getPosition_y(), network.getSensor(id2).getPosition_x(), network.getSensor(id2).getPosition_y(), configuration.getRange())){
							node1.addNeighbor(id2);	
							count++;
						}
					}
				}
				//update min max avg
				avgNeighbors+=count;
				if(count<minNeighbors){
					minNeighbors=count;
				} else if(count>maxNeighbors){
					maxNeighbors=count;
				}
				
			}
			
			avgNeighbors=avgNeighbors/network.getNodes().size();
			
		
		}
		
		
		@Override
			public String toString() {
			StringBuffer strb=new StringBuffer();
			strb.append("============= Uniform Topology =============");
			strb.append("\n\t Min # Neighbors="+minNeighbors);
			strb.append("\n\t Max # Neighbors="+maxNeighbors);
			strb.append("\n\t Avg # Neighbors="+ Math.round(avgNeighbors));
			strb.append("\n\n\n");
			return strb.toString();
			}
}
