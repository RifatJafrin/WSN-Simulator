package network;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;

import protocol.AgentDiscoveryProtocol;
import protocol.SimpleFlooding;
import simulation.Configuration;
import simulation.DiscreteEventSimulator;

public class Network {
public static Network network;
public List<Sensor> nodes;
public AgentDiscoveryProtocol agentDiscoveryProtocol;
public List<Integer>capableNodeIDs; 
public int WSNManager;
final static Logger logger = Logger.getLogger(Network.class);

public static Network getInstance(){
	if(network==null){
		network=new Network();
	}
		return network;
	
}

public Network() {
	nodes=new ArrayList<Sensor>();
	WSNManager=0;
	logger.info("Network is initialized");
	}


public void setCapableNodes() {
	Random randomGenerator = new Random();
	int numberOfCapableNodes=Configuration.getInstance().getPercentageCapableNodes()*nodes.size()/100;
	capableNodeIDs = new ArrayList<Integer>(numberOfCapableNodes);
	for (int idx = 0; idx < numberOfCapableNodes; ){
      int randomInt = randomGenerator.nextInt(nodes.size());
      if(!capableNodeIDs.contains(randomInt)){
    	  idx++;
    	  capableNodeIDs.add(randomInt);
      }
    }
	
	for(Integer id:capableNodeIDs){
		nodes.get(id).setCapable();
	}
	
	capableNodeIDs=DiscreteEventSimulator.unify(capableNodeIDs);
	logger.info("Capable node selection is done");
}


public void setWSNManager(int wSNManager) {
	this.WSNManager = wSNManager;
}

public AgentDiscoveryProtocol getAgentDiscoveryProtocol() {
	return agentDiscoveryProtocol;
}

public void setAgentDiscoveryProtocol(
		AgentDiscoveryProtocol agentDiscoveryProtocol) {
	this.agentDiscoveryProtocol = agentDiscoveryProtocol;
}

	


public Sensor getWSNManager(){
	return nodes.get(WSNManager);
}

public  void initializeNetwork() {
	for(int i=0;i<Configuration.getInstance().getNetworkSize();i++){
		Sensor sensor=new Sensor(i);
		nodes.add(sensor);
	}
}

public void print(){
	for(int i=0;i<nodes.size();i++){
		System.out.println(nodes.get(i).toString()); 
	}
}

public void process() {
	for(Sensor node:nodes){
		agentDiscoveryProtocol.process(node);
	}
	
}

public Sensor getSensor(int sensorID) {
	if(sensorID<nodes.size() || sensorID>=0){
		return nodes.get(sensorID);
	}else
		logger.error("wrong sensor id given"+ sensorID);
		return null;
}

public List<Sensor> getNodes() {
	return nodes;
}

public int getNetworkSize(){
	return nodes.size();
}

public List<Integer> getCapableNodes(){
	return capableNodeIDs;
}



@Override
	public String toString() {
		StringBuffer strb=new StringBuffer();
		strb.append("============= Network =============");
		strb.append("\n\t WSN Manager="+WSNManager);
		strb.append("\n\t Capable Nodes="+capableNodeIDs);
		strb.append("\n\n\n");
		return strb.toString();
	}

public boolean isConverged() {
	for(Sensor sensor:nodes){
		if(sensor.getMessageQueue().size()>0 || sensor.hasPendingMessage()){
			return false;
		}
	}
	logger.info("Network is converged");
	return true;
}


}
