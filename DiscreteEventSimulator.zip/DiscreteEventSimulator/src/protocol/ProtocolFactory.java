package protocol;

public class ProtocolFactory {

	public static String SIMPLE_FLOODING="simple";
	public static String AGGREGATION_FLOODING="aggregation";
	
	public static AgentDiscoveryProtocol getProtocol(String protocolName) {
		if(protocolName.equals(SIMPLE_FLOODING)){
			return new SimpleFlooding();
		}else if(protocolName.equals(AGGREGATION_FLOODING)){
			return new AggregationFlooding();
		}else{
			return null;
		}
	}
}
