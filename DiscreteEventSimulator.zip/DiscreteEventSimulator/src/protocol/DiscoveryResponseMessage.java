package protocol;

import java.util.ArrayList;
import java.util.List;

public class DiscoveryResponseMessage extends ProtocolMessage{
List<Integer> capableIDs;

public DiscoveryResponseMessage(int broadcast_id,String content,String requirement,int source_id){
	super(broadcast_id,content,requirement,source_id);
	capableIDs=new ArrayList<Integer>();
}

public void addToCapableList(int id){
	if(!capableIDs.contains(id)){
		capableIDs.add(id);
	}
}

public void addToCapableList(List<Integer> ids){
		capableIDs.addAll(ids);
}

public List<Integer> getCapableNodes(){
	return capableIDs;
}
}
