package protocol;

public class ReceivedMessage{
	int recieptionTime;
	ProtocolMessage message;
	public ReceivedMessage(ProtocolMessage message, int receiptionTime) {
		this.recieptionTime=receiptionTime;
		this.message=message;
	}
	
	public ProtocolMessage getMessage(){
		return message;
	}
}