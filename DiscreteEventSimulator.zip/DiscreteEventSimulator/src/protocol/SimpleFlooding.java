package protocol;

import network.Network;
import network.Sensor;

import org.apache.log4j.Logger;

import report.Observation;
import simulation.DiscreteEventSimulator;

public class SimpleFlooding implements AgentDiscoveryProtocol {
	Observation observation = Observation.getInstance();
	final static Logger logger = Logger.getLogger(SimpleFlooding.class);

	@Override
	public void process(Sensor sensor) {
		logger.info("================ sensor " + sensor.getId()
				+ "===================");

		while (sensor.getMessageQueue().size() != 0) {
			ReceivedMessage rcvMessage = sensor.dequeue();
			ProtocolMessage message = rcvMessage.getMessage();
			System.out.println(message.toString());

			if (message instanceof DiscoveryRequestMessage) {
				logger.debug("Discover message");

				// discard duplicate
				if (sensor.isDuplicateMessage(message.getBroadcast_id())) {
					logger.debug("continue..");
					continue;
				}
				sensor.updateCache(message.getBroadcast_id(),
						message.getSource_id(),
						DiscreteEventSimulator.currentTime);

				// check capability - reply to source if capable
				if (sensor.isCapable()) {
					logger.debug("Discover message..generating reply");
					ProtocolMessage replyMessage = MessageFactory.getMessage(
							"reply", message.getBroadcast_id(), "", "",
							sensor.getId());

					((DiscoveryResponseMessage) replyMessage)
							.addToCapableList(sensor.getId());
					replyMessage.setDestination_id(message.getSource_id());
					replyMessage.setOriginator(message.getOriginator());
					// message.setSource_id(sensor.getId());

					logger.debug(replyMessage.toString());

					if (!sensor.getNeighbors().contains(
							replyMessage.getDestination_id())) {
						logger.error("aha! wrong source.."
								+ sensor.getNeighbors() + ","
								+ replyMessage.getDestination_id());
					} else {
						observation.incrementTotalResponseMessage();
						Network.getInstance()
								.getSensor(replyMessage.getDestination_id())
								.acceptMessage(sensor.getId(), replyMessage,
										DiscreteEventSimulator.currentTime);
						logger.debug("Replying back .. " + sensor.getId()
								+ " to " + replyMessage.getDestination_id());
					}
				}

				// send to neighbor
				if (message.getOriginator() == sensor.getId()) {
					continue;
				}
				ProtocolMessage forwardMessage = MessageFactory.getMessage(
						"query", message.getBroadcast_id(), "", "",
						sensor.getId());
				forwardMessage.setOriginator(message.getOriginator());
				logger.debug("Discover message..sending to neighbors");

				for (Integer neighborID : sensor.getNeighbors()) {
					Sensor neighbor = Network.getInstance().getSensor(
							neighborID);
					if (neighbor != null) {
						observation.incrementTotalRequestMessage();
						logger.debug(forwardMessage.toString());
						neighbor.acceptMessage(sensor.getId(), forwardMessage,
								DiscreteEventSimulator.currentTime);
						logger.debug(sensor.getId() + " sending to "
								+ neighborID);
					}
				}
			} else if (message instanceof DiscoveryResponseMessage) {
				logger.debug("Response message..");
				logger.debug(message.toString());
				DiscoveryResponseMessage responseMesssage = (DiscoveryResponseMessage) message;
				// is it for me ?
				if (sensor.getId() == message.getOriginator()) {
					sensor.AddToCapableNodes(responseMesssage.getCapableNodes());
					observation.incrementACKMessage();
				} else {
					// I am not destination - now what ??
					responseMesssage.setSource_id(sensor.getId());

					int destination = sensor
							.getDestination(message.broadcast_id);
					if (destination < 0) {
						logger.error("aha! no destination found");
						return;
					}
					responseMesssage.setDestination_id(destination);
					logger.debug("Response message ... sending to destination");
					logger.debug(responseMesssage.toString());
					if (!sensor.getNeighbors().contains(destination)) {
						logger.error("aha! neighbor missing"
								+ sensor.getNeighbors() + "," + destination);
					} else {
						observation.incrementTotalResponseMessage();
						Network.getInstance()
								.getSensor(destination)
								.acceptMessage(sensor.getId(),
										responseMesssage,
										DiscreteEventSimulator.currentTime);
						logger.debug("Replying back .. " + sensor.getId()
								+ " to " + destination);
					}

				}

			}
		}

	}

}
