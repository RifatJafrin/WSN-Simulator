package protocol;

public interface Message {



}
