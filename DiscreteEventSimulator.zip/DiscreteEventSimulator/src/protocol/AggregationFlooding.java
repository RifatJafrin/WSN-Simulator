package protocol;

import java.util.ArrayList;
import java.util.List;

import network.Network;
import network.Sensor;

import org.apache.log4j.Logger;

import protocol.AggregationTable.AggregationTableEntry;
import report.Observation;
import simulation.DiscreteEventSimulator;

public class AggregationFlooding implements AgentDiscoveryProtocol {
	Observation observation = Observation.getInstance();
	final static Logger logger = Logger.getLogger(AggregationFlooding.class);

	@Override
	public void process(Sensor sensor) {
		logger.info("================ sensor " + sensor.getId()
				+ "===================");

		while (sensor.getMessageQueue().size() != 0) {
			ReceivedMessage rcvMessage = sensor.dequeue();
			ProtocolMessage message = rcvMessage.getMessage();
			System.out.println(message.toString());

			if (message instanceof DiscoveryRequestMessage) {
				logger.debug("Discover message");

				// discard duplicate
				if (sensor.isDuplicateMessage(message.getBroadcast_id())) {
					logger.debug("continue..");
					continue;
				}
				sensor.updateCache(message.getBroadcast_id(),
						message.getSource_id(),
						DiscreteEventSimulator.currentTime);

				// check capability - reply to source if capable
				if (sensor.isCapable()) {
					// update aggregation table
					sensor.updateAggregationTable(message.getBroadcast_id(),
							message.getOriginator(),
							sensor.getId());
				}

				// send to neighbor
				if (message.getOriginator() == sensor.getId()) {
					continue;
				}
				ProtocolMessage forwardMessage = MessageFactory.getMessage(
						"query", message.getBroadcast_id(), "", "",
						sensor.getId());
				forwardMessage.setOriginator(message.getOriginator());
				logger.debug("Discover message..sending to neighbors");

				for (Integer neighborID : sensor.getNeighbors()) {
					Sensor neighbor = Network.getInstance().getSensor(
							neighborID);
					if (neighbor != null) {
						observation.incrementTotalRequestMessage();
						logger.debug(forwardMessage.toString());
						neighbor.acceptMessage(sensor.getId(), forwardMessage,
								DiscreteEventSimulator.currentTime);
						logger.debug(sensor.getId() + " sending to "
								+ neighborID);
					}
				}
			} else if (message instanceof DiscoveryResponseMessage) {
				logger.debug("Response message..");
				logger.debug(message.toString());
				DiscoveryResponseMessage responseMesssage = (DiscoveryResponseMessage) message;
				// is it for me ?
				if (sensor.getId() == message.getOriginator()) {
					sensor.AddToCapableNodes(responseMesssage.getCapableNodes());
					observation.incrementACKMessage();
				} else {
					// update aggregation table
					sensor.updateAggregationTable(message.getBroadcast_id(),
							message.getOriginator(),
							((DiscoveryResponseMessage) message)
									.getCapableNodes());
				}
			}
		}

		// when message queue is empty
		List<AggregationTableEntry> aggregatedRecords = sensor
				.processAgrregatedMessage();
		if(aggregatedRecords==null){
			return;
		}
		for (AggregationTableEntry record : aggregatedRecords) {
			ProtocolMessage replyMessage = MessageFactory.getMessage("reply",
					record.getBroadcast_id(), "", "", sensor.getId());

			replyMessage.setSource_id(sensor.getId());
			replyMessage.setBroadcast_id(record.getBroadcast_id());
			replyMessage.setOriginator(record.getOriginator());
			replyMessage.setDestination_id(sensor.getDestination(record
					.getBroadcast_id()));

			((DiscoveryResponseMessage) replyMessage).addToCapableList(record
					.getCapableNodes());

			logger.debug(replyMessage.toString());

			if (!sensor.getNeighbors().contains(
					replyMessage.getDestination_id())) {
				logger.error("aha! wrong source.." + sensor.getNeighbors()
						+ "," + replyMessage.getDestination_id());
			} else {
				observation.incrementTotalResponseMessage();
				Network.getInstance()
						.getSensor(replyMessage.getDestination_id())
						.acceptMessage(sensor.getId(), replyMessage,
								DiscreteEventSimulator.currentTime);
				logger.debug("Replying back .. " + sensor.getId() + " to "
						+ replyMessage.getDestination_id());
			}
		}

	}

}
