package protocol;

public abstract class ProtocolMessage implements Message {
	int broadcast_id;
	String content;
	String requirement;
	int source_id;
	int destination_id;
	int originator;

	public ProtocolMessage(int broadcast_id, String content,
			String requirement, int source_id) {
		this.broadcast_id = broadcast_id;
		this.content = content;
		this.requirement = requirement;
		this.source_id = source_id;
		this.destination_id = -1;

	}

	public int getBroadcast_id() {
		return broadcast_id;
	}

	public void setBroadcast_id(int broadcast_id) {
		this.broadcast_id = broadcast_id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

	public int getSource_id() {
		return source_id;
	}

	public void setSource_id(int source_id) {
		this.source_id = source_id;
	}

	public int getOriginator() {
		return originator;
	}

	public void setOriginator(int originator) {
		this.originator = originator;
	}

	public int getDestination_id() {
		return destination_id;
	}

	public void setDestination_id(int destination_id) {
		this.destination_id = destination_id;
	}

	public void updateSourceId(int id) {
		source_id = id;
	}

	@Override
	public String toString() {
		return "Message=>org=" + originator + ":id=" + broadcast_id
				+ ":source=" + source_id + ":dst=" + destination_id;
	}
}
