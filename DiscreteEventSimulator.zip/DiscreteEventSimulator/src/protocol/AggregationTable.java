package protocol;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import simulation.Configuration;
import simulation.DiscreteEventSimulator;

public class AggregationTable {
	List<AggregationTableEntry> table;

	public AggregationTable() {
		table = new ArrayList<AggregationTable.AggregationTableEntry>(1);
	}
	


	public void updateAggregationTable(int broadcast_id, int originator,
			List<Integer> capableNodes) {
		for (AggregationTableEntry entry : table) {
			if (entry.getBroadcast_id() == broadcast_id) {
				entry.addCapableNodes(capableNodes);
				if (entry.getSendTime() > entry.getRecieptionTime()) {// this
																		// means
																		// sent
																		// before
					entry.setRecieptionTime(DiscreteEventSimulator.currentTime);
					return;
				}
			}
		}
		// add new entry
		AggregationTableEntry newEntry = new AggregationTableEntry();
		newEntry.setBroadcast_id(broadcast_id);
		newEntry.setOriginator(originator);
		newEntry.addCapableNodes(capableNodes);
		newEntry.setRecieptionTime(DiscreteEventSimulator.currentTime);
		newEntry.setSendTime(-1); // this means not sent yet

		table.add(newEntry);
	}

	public List<AggregationTableEntry> generateResponseMessageRecords() {
		// todo utilize TimeToSendResponseMessage()
		
		List<AggregationTableEntry> entries=new ArrayList<AggregationTable.AggregationTableEntry>();
		for (AggregationTableEntry entry : table) {
			if(entry.getRecieptionTime()>entry.getSendTime() && TimeToSendResponseMessage(entry.getRecieptionTime())){
				entries.add(entry);
				entry.setSendTime(DiscreteEventSimulator.currentTime);
			}
		}
		return entries;
	}




	private boolean TimeToSendResponseMessage(int receiptionTime) {
		Random generator = new Random();
		int r = generator.nextInt(100);
		int e = DiscreteEventSimulator.currentTime-receiptionTime;
		int l = Configuration.getInstance().getWaitingTime() + 1;
		
		if (r < 100 * e / l) {
			return true;
		}
	
		return false;
	}

	
	public boolean doesHavePendingMessage() {
		for (AggregationTableEntry entry : table) {
			if(entry.getRecieptionTime()>entry.getSendTime()){
				return true;
			}
		}
		return false;
	}
	
	
	public class AggregationTableEntry {
		int broadcast_id;
		List<Integer> capableNodes;
		int recieptionTime;
		int sendTime;
		int originator;

		public int getOriginator() {
			return originator;
		}

		public void setOriginator(int originator) {
			this.originator = originator;
		}

		public AggregationTableEntry() {
			capableNodes = new ArrayList<Integer>();
		}

		public int getBroadcast_id() {
			return broadcast_id;
		}

		public void setBroadcast_id(int broadcast_id) {
			this.broadcast_id = broadcast_id;
		}

		public List<Integer> getCapableNodes() {
			return capableNodes;
		}

		
		public void addCapableNodes(List<Integer> capableNodes) {
			for(Integer n:capableNodes){
				if(!this.capableNodes.contains(n)){
					this.capableNodes.add(n);
				}
			}
		}
		public int getRecieptionTime() {
			return recieptionTime;
		}

		public void setRecieptionTime(int recieptionTime) {
			this.recieptionTime = recieptionTime;
		}

		public int getSendTime() {
			return sendTime;
		}

		public void setSendTime(int sendTime) {
			this.sendTime = sendTime;
		}

	}


}
