package protocol;


public class MessageFactory {

	public static ProtocolMessage getMessage(String messageType,int broadcast_id,String content,String requirement,int source_id) {
		if(messageType.equals("query")){
			return new DiscoveryRequestMessage( broadcast_id, content, requirement, source_id);
		}else if(messageType.equals("reply")){
			return new DiscoveryResponseMessage( broadcast_id, content, requirement, source_id);
		}else{
			return null;
		}
	}
}
