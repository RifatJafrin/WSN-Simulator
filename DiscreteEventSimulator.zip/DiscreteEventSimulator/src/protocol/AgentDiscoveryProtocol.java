package protocol;

import network.Sensor;

public interface AgentDiscoveryProtocol {
	public void process(Sensor sensor);
}
