package protocol;



public class DiscoveryRequestMessage extends ProtocolMessage {
	int broadcast_id;
	String content;
	String requirement;
	int source_id;
	
public DiscoveryRequestMessage(int broadcast_id,String content,String requirement,int source_id){
	super(broadcast_id,content,requirement,source_id);
}
}





