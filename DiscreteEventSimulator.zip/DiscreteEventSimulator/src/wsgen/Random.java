package wsgen;

public class Random {

	Random r;
        static final long SEED=System.currentTimeMillis();
	
       public Random() {
		r=new Random(SEED);
	}
	
	public Random(long seed2) {
		// TODO Auto-generated constructor stub
	}

	public int nextRandom(int a, int b) {
		if (a==b) return a;
		else return (a+r.nextInt(b-a+1));
	}
	
	private int nextInt(int i) {
		// TODO Auto-generated method stub
		return 0;
	}

	public double nextRandom() {
		return r.nextDouble();
	}
	
	
	private double nextDouble() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double nextPoisson(int intensite)	{
	  double y, resultat=0;
	  int i, nonTrouve;
	  int max, min;
	  min = (int)(intensite - 2 * Math.sqrt(intensite));
	  max = (int)(intensite + 2 * Math.sqrt(intensite));
	  nonTrouve = 1;
	  y = nextRandom() * somme(intensite, max);
	  i =min;
	  while((nonTrouve == 1)&&(i<max +1)) {
	      if (y < somme(intensite,i)) {
	          resultat = i;
	          nonTrouve = 0;
	        }
	      i++;
	    }
	  return (resultat);
	}

	double fonctionGaussienne(int intensite, int val) {
	  return ( (1/(2*Math.PI*Math.sqrt((double) intensite))) * Math.exp(-(double)Math.pow(val-intensite,2)/(2.0*intensite)) );
	}
	
	double somme(int intensite, int max) {
	  double somme=0;
	  int i = (int)(intensite - 2*Math.sqrt(intensite));
	  while (i < max+1) {
	      somme += fonctionGaussienne(intensite,i);
	      i++;
      }
	  return somme;
	}
	
	double fact(int n) {
	  if (n==0) return 1;
	  else
	    return n*fact(n-1);
	}


}
