package simulation;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import network.Network;

import org.apache.log4j.Logger;

public class Configuration {
	public static int PROTOCOL_SIMPLE_FLOODING = 0;
	public static int PROTOCOL_DELAY_FLOODING = 1;
	public static int RANDOM_WAITING_TIME = -1;
	public static Configuration configuration;

	int networkSize;

	int waitingTime;
	int density;
	int percentageCapableNodes;
	int gridWidth;
	int gridDistance;
	double connectionRange;
	String protocol;
	Boolean graphShow;
	String expFileName;
	double mean;
	String topology;
	double standardDeviation;

	final static Logger logger = Logger.getLogger(Configuration.class);
	


	
	
	public static Configuration getInstance() {
		if (configuration == null) {
			configuration = new Configuration();
		}
		return configuration;
	}

	void loadConfigurations(String filename) {

		Properties config = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream(filename);
			config.load(input);

			setNetworkSize(Integer.parseInt(config.getProperty("networkSize")));
			setDensity(Integer.parseInt(config.getProperty("networkDensity")));
			setPercentageCapableNodes(Integer.parseInt(config
					.getProperty("percentageCapableNodes")));
			setProtocol(config.getProperty("protocol"));
			setWaitingTime(Integer.parseInt(config.getProperty("waitingTime")));
			setWidth(Integer.parseInt(config.getProperty("gridWidth")));
			setRadius(Integer.parseInt(config.getProperty("gridDistance")));
			setRange(Double.parseDouble(config.getProperty("connectionRange")));
			setGraphShow(Boolean.parseBoolean(config.getProperty("graphShow")));
			setTopology(config.getProperty("topology"));
			setMean(Double.parseDouble(config.getProperty("mean")));
			setStandardDeviation(Double.parseDouble(config.getProperty("standardDeviation")));

			logger.info("Configuration file is loaded");
		} catch (IOException ex) {
			logger.error("Configuration file is not loaded"+ ex.toString());
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public Boolean getGraphShow() {
		return graphShow;
	}

	public void setGraphShow(Boolean graphShow) {
		this.graphShow = graphShow;
	}

	public int getSensorRadius() {
		return gridDistance;
	}

	public void setSensorRadius(int sensorRadius) {
		this.gridDistance = sensorRadius;
	}

	public int getNetworkSize() {
		return networkSize;
	}

	public void setNetworkSize(int networkSize) {
		this.networkSize = networkSize;
	}

	public int getWaitingTime() {
		return waitingTime;
	}

	public void setWaitingTime(int waitingTime) {
		this.waitingTime = waitingTime;
	}

	public int getDensity() {
		return density;
	}

	public void setDensity(int density) {
		this.density = density;
	}

	public int getPercentageCapableNodes() {
		return percentageCapableNodes;
	}

	public void setPercentageCapableNodes(int percentageCapableNodes) {
		this.percentageCapableNodes = percentageCapableNodes;
	}

	@Override
	public String toString() {
		StringBuffer strb = new StringBuffer();
		strb.append("============= Configurations =============");
		strb.append("\n\t Network size=" + networkSize);
		strb.append("\n\t Network protocol=" + protocol);
		strb.append("\n\t Forwarding Time=" + waitingTime);
		strb.append("\n\t Percentage Capable Nodes=" + percentageCapableNodes);
		strb.append("\n\t Grid Width=" + gridWidth);
		strb.append("\n\t Node distance=" + gridDistance);
		strb.append("\n\t Connectivity Radius=" + connectionRange);

		return strb.toString();
	}

	public void print() {
		System.out.println(this.toString());

	}

	private void setProtocol(String protocol) {
		this.protocol = protocol;

	}

	public String getProtocol() {
		return protocol;

	}

	private void setRange(double range) {
		this.connectionRange = range;

	}

	private void setRadius(int radius) {
		this.gridDistance = radius;

	}

	private void setWidth(int width) {
		this.gridWidth = width;

	}

	public int getWidth() {
		return gridWidth;
	}

	public double getRange() {
		return connectionRange;

	}

	public void setExperimentName(String filename) {
		this.expFileName = filename;

	}

	public String getExperimentName() {
		return expFileName;

	}

	public String getTopology() {
		return topology;
	}

	public void setTopology(String topology) {
		this.topology = topology;
	}

	public double getMean() {
		return mean;
	}

	public double getStandardDeviation() {
		return standardDeviation;
	}

	public void setMean(double mean) {
		this.mean = mean;
	}

	public void setStandardDeviation(double standardDeviation) {
		this.standardDeviation = standardDeviation;
	}


}
