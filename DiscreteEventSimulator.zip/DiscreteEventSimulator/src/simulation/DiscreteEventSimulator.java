package simulation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import network.Network;
import network.Topology;
import network.TopologyFactory;

import org.apache.log4j.Logger;

import protocol.AgentDiscoveryProtocol;
import protocol.MessageFactory;
import protocol.ProtocolFactory;
import protocol.ProtocolMessage;
import report.Observation;
import report.ReportObservations;

public class DiscreteEventSimulator {

	public static int currentTime;
	Network network = Network.getInstance();
	Observation observation = Observation.getInstance();
	final static Logger logger = Logger.getLogger(DiscreteEventSimulator.class);
	
	
	public static void main(String[] args) {
		if (args.length > 0) {
			String filename = args[0];
			DiscreteEventSimulator discreteEventSimulator = new DiscreteEventSimulator();
			discreteEventSimulator.runSimulation(filename);
			ReportObservations.getInstance().save();
			logger.info("Terminates ...");

		}
	}

	private void runSimulation(String filename) {
		// TODO Auto-generated method stub
		logger.info("Simulation settings ..");
		currentTime = 0;
		Configuration.getInstance().loadConfigurations(filename);
		Configuration.getInstance().setExperimentName(filename);
				
		Topology topology=TopologyFactory.getTopology(Configuration.getInstance().getTopology());
		if(topology==null){
			logger.error("Null topology !");
			System.exit(1);
		}
		topology.build();
		topology.print();

		if (Configuration.getInstance().getGraphShow()) {
			//GridTopology.getInstance().showTopology();
			topology.showTopology();
		}
		
		logger.info("Simulation starts ...");
		Simulate();
		logger.info("Simulation ends ...");
	}

	private void Simulate() {

		Random randomGenerator = new Random();
		//int WSNManagerID = randomGenerator.nextInt(Network.getInstance()
				//.getNetworkSize());
				int WSNManagerID = (Network.getInstance()
						.getNetworkSize())/2;
		Network.getInstance().setWSNManager(WSNManagerID);

		ProtocolMessage message = MessageFactory.getMessage("query", 1, "", "",
				WSNManagerID);
		message.setOriginator(WSNManagerID);
		message.setSource_id(WSNManagerID);
		for (Integer neighborID : network.getSensor(WSNManagerID)
				.getNeighbors()) {
			network.getSensor(neighborID).acceptMessage(WSNManagerID, message,
					0);
		}

		AgentDiscoveryProtocol protocol=ProtocolFactory.getProtocol(Configuration.getInstance()
				.getProtocol());
		if(protocol==null){
			logger.error("Null protocol !");
			System.exit(1);
		}
		Network.getInstance().setAgentDiscoveryProtocol(protocol);
		Network.getInstance().setCapableNodes();
		System.out.println("selected nodes:" + network.getCapableNodes());

		while (!network.isConverged()) {
			currentTime++;
			Network.getInstance().process();
		}
		observation.SetConvergenceTime(currentTime);
		System.out.println("Capable nodes:" + network.getCapableNodes());
		System.out.println("Found nodes:"
				+ unify(network.getSensor(WSNManagerID).getCapableNodes()));

	}
	
	public static ArrayList<Integer> unify(List<Integer> capableNodes) {
		if(capableNodes==null || capableNodes.isEmpty()){
			return new ArrayList<Integer>();
					
		}
		Set<Integer> uniqueList = new HashSet<Integer>(capableNodes);
		ArrayList<Integer> list=new ArrayList<Integer>(uniqueList);
		Collections.sort(list);
		return list;
	}


}
