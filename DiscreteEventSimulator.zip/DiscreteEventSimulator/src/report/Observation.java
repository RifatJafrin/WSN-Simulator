package report;

public class Observation {
	public static Observation observation;

	int totalRequestMessage;

	int totalResponseMessage;
	int convergenceTime;
	int totalACKMessages;

	private Observation() {
		totalRequestMessage = 0;
		totalResponseMessage = 0;
		convergenceTime = 0;
		totalACKMessages = 0;

	}

	public static Observation getInstance() {
		if (observation == null) {
			observation = new Observation();
		}
		return observation;
	}

	public int getTotalRequestMessage() {
		return totalRequestMessage;
	}

	public void incrementTotalRequestMessage() {
		totalRequestMessage++;
	}

	public int getTotalResponseMessage() {
		return totalResponseMessage;
	}

	public void incrementTotalResponseMessage() {
		totalResponseMessage++;
	}

	public int getConvergenceTime() {
		return convergenceTime;
	}

	public void SetConvergenceTime(int converganceTime) {
		this.convergenceTime = converganceTime;
	}

	public int getACKMessage() {
		return totalACKMessages;
	}

	public void incrementACKMessage() {
		totalACKMessages++;
	}

	@Override
	public String toString() {
		StringBuffer strb = new StringBuffer();
		strb.append("============= REPORT ==================");
		strb.append("\n\tTotal Broadcasted Messages:" + totalRequestMessage);
		strb.append("\n\tTotal Response Messages:" + totalResponseMessage);

		strb.append("\n\tTotal ACK received by WSN manager:" + totalACKMessages);
		strb.append("\n\tConvergence Time:" + convergenceTime);
		return strb.toString();

	}
}
