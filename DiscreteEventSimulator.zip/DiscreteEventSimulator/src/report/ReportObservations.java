package report;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.log4j.Logger;

import network.GridTopology;
import network.Network;
import network.TopologyFactory;
import simulation.Configuration;

public class ReportObservations {
	public static ReportObservations reportObservations;
	final static Logger logger = Logger.getLogger(ReportObservations.class);
	
	
	public static ReportObservations getInstance() {
		if (reportObservations == null) {
			reportObservations = new ReportObservations();
		}
		return reportObservations;
	}

	public void save() {
		try {
			String reportFileName = Configuration.getInstance()
					.getExperimentName();
			reportFileName = reportFileName.replace("properties", "report");

			File file = new File("report/"+reportFileName);

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(Configuration.getInstance().toString() + "\n\n\n");
			bw.write(Network.getInstance().toString() + "\n");
			bw.write(TopologyFactory.getTopology(Configuration.getInstance().getTopology()).toString() + "\n");
			bw.write(Observation.getInstance().toString());
			if(Network.getInstance().getWSNManager().getCapableNodes()!=null){
				bw.write("\n\tWSN Manager Identify:"
						+ Network.getInstance().getWSNManager().getCapableNodes()
								.toString());	
			}else{
				bw.write("\n\tWSN Manager Identify: []");
			}

			bw.close();
		} catch (IOException e) {
			logger.error("report is not saved"+ e.toString());
			e.printStackTrace();
		}

	}
}
